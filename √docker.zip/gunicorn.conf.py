# ── gunicorn.conf.py ──────────────────────────────────────────────────────────
# Drop this in the root of your backend directory.
# ──────────────────────────────────────────────────────────────────────────────

import multiprocessing

# Bind
bind = "0.0.0.0:5000"

# Workers: 2–4 × CPU cores is the standard recommendation for I/O-bound apps
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "sync"      # swap for "gevent" if you add async I/O

# Timeouts
timeout = 60               # kill workers that take longer than 60 s
graceful_timeout = 30      # wait up to 30 s for in-flight requests on restart
keepalive = 5

# Logging — gunicorn logs go to stdout/stderr so Docker captures them
accesslog = "-"
errorlog  = "-"
loglevel  = "info"

# Security
limit_request_line   = 4096
limit_request_fields = 100
