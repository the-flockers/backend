# ── Backend Dockerfile ────────────────────────────────────────────────────────
# Flask + Gunicorn | Python 3.12-slim
# ──────────────────────────────────────────────────────────────────────────────

FROM python:3.12-slim AS base

# System deps (psycopg2 needs libpq)
RUN apt-get update && apt-get install -y --no-install-recommends \
    libpq-dev \
    gcc \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /app

# Install Python deps first (layer-cache friendly)
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application source
COPY . .

# Create logs directory (Flask writes rotating logs here)
RUN mkdir -p logs

# Non-root user for security
RUN useradd -m appuser && chown -R appuser:appuser /app
USER appuser

EXPOSE 5000

# Run DB migrations then start Gunicorn
CMD ["sh", "-c", "flask db upgrade && gunicorn --config gunicorn.conf.py 'app:create_app(\"production\")'"]
