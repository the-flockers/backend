# ── Frontend Dockerfile ───────────────────────────────────────────────────────
# Stage 1: Build Jekyll → _site/
# Stage 2: Serve with Nginx
# ──────────────────────────────────────────────────────────────────────────────

# ── BUILD STAGE ───────────────────────────────────────────────────────────────
FROM ruby:3.3-slim AS builder

RUN apt-get update && apt-get install -y --no-install-recommends \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

WORKDIR /site

# Install gems first (layer cache)
COPY Gemfile Gemfile.lock* ./
RUN bundle install --jobs 4 --retry 3

# Copy source and build
COPY . .
RUN bundle exec jekyll build --destination _site

# ── SERVE STAGE ───────────────────────────────────────────────────────────────
FROM nginx:1.27-alpine AS serve

# Remove default nginx config
RUN rm /etc/nginx/conf.d/default.conf

# Copy our custom nginx config
COPY nginx.conf /etc/nginx/conf.d/app.conf

# Copy built Jekyll site
COPY --from=builder /site/_site /usr/share/nginx/html

EXPOSE 80

CMD ["nginx", "-g", "daemon off;"]
